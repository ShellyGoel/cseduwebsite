
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.StringTokenizer;

public class MentalHealth {
	static Scanner scan = new Scanner(System.in);
	
	static ArrayList<MentalHealthObject> resources;
	
	public static void main (String[] args) {
		welcomeMessage();
		resources = new ArrayList<MentalHealthObject>();
		readFile();
		String message = inputMessage();
		readAndProcessMessage(message);
		printResources();
		askForMoreResources();
	}
	
	private static void welcomeMessage() {
		System.out.println("Welcome to the Mental Health Database!");
		System.out.println("This database is designed to help match you or someone you concern for with the most suitable resource(s).");
	}
	
	private static void readFile() {
		try {
    		BufferedReader rd = new BufferedReader(new FileReader("mentalhealthdatabase.txt"));
    		while (true) {
    			String line = rd.readLine();
    			break; // Compiling purposes
    			// TO DO
    		}
    		rd.close();
    	} 
    	catch (IOException ex) {
    		System.out.println("Error has occurred.");
    	}
	}

	private static String inputMessage() {
		// TO DO
		return ""; // Compiling purposes
	}
	
	private static void readAndProcessMessage(String message) {
		// TO DO
		StringTokenizer tokenizer = new StringTokenizer(message," ");
	}
	
	private static void printResources() {
		// TO DO
	}
	
	private static void askForMoreResources() {
		// TO DO
	}
}
