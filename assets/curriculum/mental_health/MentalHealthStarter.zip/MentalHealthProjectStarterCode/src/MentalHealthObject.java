import java.util.ArrayList;
import java.util.StringTokenizer;

public class MentalHealthObject {
	
	// TO DO: instance variables

	//Optional: loadKeyWords can be called by the constructor
	public MentalHealthObject(String fileLine) {
		// TO DO
	}
	
	public boolean containKeyWords(String inputWord) {
		// TO DO 
		return false; // Compiling purposes
	}
	
	public String getOutputLine() {
		// TO DO
		return ""; // Compiling purposes
	}
	
	public void incrementOccurence() {
		// TO DO
	}
	
	public int getOccurences() {
		// TO DO
		return 0; // Compiling purposes
	}
	
	private void loadKeyWords(String line) {
		// TO DO
	}
}
