import java.util.*;

public class HospitalProgram {
	
	private static final String SYMPTOMS = "\n\tList of symptoms:" +
		"\n\tSymptom 1: Bloating" + "\n\tSymptom 2: Coughing" + 
		"\n\tSymptom 3: Diarrhea" + "\n\tSymptom 4: Dizziness" + 
		"\n\tSymptom 5: Fatigue" + "\n\tSymptom 6: Fever" + 
		"\n\tSymptom 7: Headache" + "\n\tSymptom 8: Muscle Cramp" + 
		"\n\tSymptom 9: Nausea" + "\n\tSymptom 10: Throat Irritation\n";
	private static final int NUM_OF_SYMPTOMS = 10;

	/** Runs main program. */
	public static void main(String args[]) {
		// Welcome
		System.out.println("Welcome to the Hospital Database!\n");
		while(true) {
			System.out.println("------------------------------------------------------------");
			System.out.print("Add, Lookup, or Delete a patient? (type 'q' to quit): ");
			String toDo = sc.nextLine();
			if (toDo.equals("Add")) {
				add();
				sc.nextLine(); // skip
			} else if (toDo.equals("Lookup")) {
				lookUp();
			} else if (toDo.equals("Delete")) {
				delete();
			} else if (toDo.equals("q")) {
				break;
			} else {
				System.out.println("Please input a valid command.");
			}
		}		
	}

	/** Adds a patient to the database. */
	private static void add() {
		// Read in patient info
		System.out.println("\nFull name of patient: ");
		String name = sc.nextLine();
		while (database.containsKey(name)) {
			System.out.println("That patient already exists in the database. ");
			System.out.println("Full name of patient: ");
			name = sc.nextLine();
		}
		System.out.println("Age: ");
		int age = sc.nextInt();
		sc.nextLine(); // skip
		System.out.println("Sex: ");
		String sex = sc.nextLine();
		System.out.println("Date of Birth (MM/DD/YYYY): ");
		String dob = sc.nextLine();

		// Create ArrayList of symptoms
		int[] symptoms = new int[NUM_OF_SYMPTOMS];
		symptoms = inputSymptoms();

		// Create patient profile
		PatientProfile patient = new PatientProfile(name, age, sex, dob, symptoms);

		// Determines and sets disease
		patient.setDisease(diseases.calcDisease(patient));
		System.out.println("\n" + name + " has been diagnosed with " + 
							patient.getDisease() + ".");

		// Confirmation
		database.put(name, patient);
		System.out.println(name + " has been added to the database!\n");
		System.out.println("\tCurrent patients on file:\n" + printPatients(database));
	}

	/** Reads in the symptoms of the patient from the user. */
	private static int[] inputSymptoms() {
		// Array of symptoms
		int[] symptoms = new int[NUM_OF_SYMPTOMS];
		System.out.println("For each possible symptom, type 0 for no, 1 for yes.");
		System.out.println(SYMPTOMS);

		// Read in symptoms
		for (int i = 0; i < NUM_OF_SYMPTOMS; i++) {
			System.out.println("Experiencing symptom " + (i+1) + "? ");
			int symp = sc.nextInt();
			while (symp != 0 && symp != 1) {
				System.out.println("Please input a valid command (0 or 1).");
				System.out.println("Experiencing symptom " + (i+1) + "? ");
				symp = sc.nextInt();
			}
			symptoms[i] = symp;
		}
		return symptoms;
	}
	
	/** Prints out current patients on file. */
	private static String printPatients(Map<String, PatientProfile> database) {
		String print = "";
		if (database.keySet().isEmpty()) {
			print = "\t(no patients)\n";
		} else {
			for (String patient: database.keySet()) {
				print += "\t" + patient + "\n";
			}
		}
		return print;
	}

	/** Looks up a patient in the database. */
	private static void lookUp() {
		System.out.println("\nName of the person you'd like to look up? ");
		String toLookUp = sc.nextLine();
		if (database.containsKey(toLookUp)) {
			System.out.println("\n" + database.get(toLookUp).toString() + "\n");
		} else {
			System.out.println("\nThis patient doesn't exist.\n");		
		}
	}

	/** Deletes a patient from the database. */
	private static void delete() {
		System.out.println("\nName of the person you'd like to delete? ");
		String toDelete = sc.nextLine();
		if (database.containsKey(toDelete)) {
			database.remove(toDelete);
			System.out.println("\nThis patient has been deleted from the database.\n");
			System.out.println("\tCurrent patients on file:\n" + printPatients(database));
		} else {
			System.out.println("\nThis patient doesn't exist.\n");
		}
	}

	/** Private instance variables. */
	static Scanner sc = new Scanner(System.in);
	private static DiseaseDataBase diseases = new DiseaseDataBase("disease_list.txt");
	private static Map<String, PatientProfile> database = new HashMap<String, PatientProfile>();
}
