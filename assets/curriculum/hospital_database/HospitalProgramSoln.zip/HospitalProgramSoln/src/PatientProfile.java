public class PatientProfile {

	/** Sets the name, age, date of birth, and the symptoms of the profile. */
	public PatientProfile(String name, int age, String sex, String dob, int[] symptoms) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.dob = dob;
		this.symptoms = symptoms;
	}

	/** Returns the symptoms of the profile. */ 
	public int[] getSymptoms() {
		return symptoms;
	}

	/** Returns the disease associated with the profile. */ 
	public String getDisease() {
		return disease;
	}

	/** Sets the patient's disease to specified disease. */ 
	public void setDisease(String disease) {
		this.disease = disease;
	}

	/** This method returns a string representation of the profile. */ 
	public String toString() {
		return "Name: " + name + 
			   "\nAge: " + age + 
			   "\nSex: " + sex +
			   "\nDate of Birth: " + dob + 
			   "\nDisease: " + disease;
	}

	/** Private instance variables. */
	private String name, disease, dob, sex;
	private int age;
	private int[] symptoms;
}