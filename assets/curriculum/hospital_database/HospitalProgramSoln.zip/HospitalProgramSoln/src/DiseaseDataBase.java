import java.io.*;
import java.util.*;

public class DiseaseDataBase {

	private static final int NUM_OF_SYMPTOMS = 10;

	/** Reads in text file and puts diseases and symptoms in a map */
	public DiseaseDataBase(String filename) {
		try {
			BufferedReader rd = new BufferedReader(new FileReader(filename));
			while (true) {
				String line = rd.readLine();
				if (line == null) break;
				String name = line.substring(0, line.indexOf("-") - 1);
				int[] symptoms = parseSymptoms(line);
				database.put(name, symptoms);
			}
			rd.close();
		} catch(IOException ex) {
			System.out.println("Error encountered getting user input:" + ex.getMessage());
		}
	}

	/** Parses through txt file to return an array of symptoms. */
	private int[] parseSymptoms(String line) {
		int[] symptoms = new int[NUM_OF_SYMPTOMS];
		int start = line.indexOf("-") + 2;
		int end = line.indexOf(" ", start);
		for (int i = 0; i < NUM_OF_SYMPTOMS - 1; i++) {
			symptoms[i] = Integer.parseInt(line.substring(start, end));
			start = end + 1;
			end = line.indexOf(" ", start);
		}
		symptoms[NUM_OF_SYMPTOMS - 1] = Integer.parseInt(line.substring(start));
		return symptoms;
	}
	/** Calculates the most probable disease based off of cosine similarity. */
	public String calcDisease(PatientProfile patient) {
		double best = 0;
		String disease = "";
		for (String name: database.keySet()) {
			double sim = cosineSim(patient.getSymptoms(), database.get(name));
			if (sim > best) {
				best = sim;
				disease = name;
			}
		}
		if (best == 0) {
			return "no disease (no symptoms!)";
		}
		return disease;
	}

	/** Runs the cosine similarity algorithm, returns the similarity. */
	private double cosineSim(int[] list1, int[] list2) {
		int mag1 = 0;
		int mag2 = 0;
		int numerator = 0;
		for (int i = 0; i < NUM_OF_SYMPTOMS; i++) {
			mag1 += list1[i] * list1[i];
			mag2 += list2[i] * list2[i];
			numerator += list1[i] * list2[i];
		}
		double denominator = Math.sqrt(mag1) * Math.sqrt(mag2);
		return (numerator / denominator);
	}

	/** Private instance variables. */
	private Map<String, int[]> database = new HashMap<String, int[]>();
}
