public class PatientProfile {

	/** Sets the name, age, sex, date of birth, and the symptoms of the profile. */
	public PatientProfile(String name, int age, String sex, String dob, int[] symptoms) {
		/*
		 * TO-DO: Write your own code here.
		 */
	}

	/** Returns the symptoms of the profile. */ 
	public int[] getSymptoms() {
		/*
		 * TO-DO: Delete this line and write your own code here.
		 */
		return null;
	}

	/** Returns the disease associated with the profile. */ 
	public String getDisease() {
		/*
		 * TO-DO: Delete this line and write your own code here.
		 */
		return "";
	}

	/** Sets the patient's disease to specified disease. */ 
	public void setDisease(String disease) {
		/*
		 * TO-DO: Write your own code here.
		 */
	}

	/** This method returns a string representation of the profile. */ 
	public String toString() {
		/*
		 * TO-DO: Delete this line and write your own code here.
		 */
		return "";
	}
}
