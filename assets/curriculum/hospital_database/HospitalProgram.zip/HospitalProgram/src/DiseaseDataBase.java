import java.io.*;
import java.util.*;

public class DiseaseDataBase {

	/** Reads in text file and puts diseases and symptoms in a map. */
	public DiseaseDataBase(String filename) {
		try {
			BufferedReader rd = new BufferedReader(new FileReader(filename));
			while (true) {
				String line = rd.readLine();
				if (line == null) break;
				/*
				 * TO-DO: Write your own code here.
				 */
			}
			rd.close();
		} catch(IOException ex) {
			System.out.println("Error encountered getting user input:" + ex.getMessage());
		}
	}

	/** Calculates the most probable disease based off of cosine similarity. */
	public String calcDisease(PatientProfile patient) {
		/*
		 * TO-DO: Delete this line and write your own code here.
		 *
		 * Hint: Implement the cosine similarity algorithm as a private method 
		 * (below) and integrate it into this method.
		 */
		return "";
	}

	/** Runs the cosine similarity algorithm, returns the similarity. */
	private double cosineSim(int[] list1, int[] list2) {
		/*
		 * TO-DO: Delete this line and write your own code here.
		 */
		return 0;
	}
}
