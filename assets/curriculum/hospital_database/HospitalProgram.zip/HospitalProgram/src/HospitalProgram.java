import java.util.*;

public class HospitalProgram {

	/** List of the symptoms (needed to print later in program). */
	private static final String SYMPTOMS = "\n\tList of symptoms:" +
		"\n\tSymptom 1: Bloating" + "\n\tSymptom 2: Coughing" + 
		"\n\tSymptom 3: Diarrhea" + "\n\tSymptom 4: Dizziness" + 
		"\n\tSymptom 5: Fatigue" + "\n\tSymptom 6: Fever" + 
		"\n\tSymptom 7: Headache" + "\n\tSymptom 8: Muscle Cramp" + 
		"\n\tSymptom 9: Nausea" + "\n\tSymptom 10: Throat Irritation\n";

	/** Runs main program. */
	public static void main(String args[]) {
		// Welcome
		System.out.println("Welcome to the Hospital Database!");

		while(true) {
			/*
		 	 * TO-DO: Write your own code here.
		 	 *
		 	 * Hint: Prompt user for a command (add, lookup, or delete a
		 	 * patient), implement private methods (below) for each command,
		 	 * and call the corresponding method based off of the user's 
		 	 * response.
		 	 */
		}		
	}

	/** Adds a patient to the database. */
	private static void add() {
		/*
		 * TO-DO: Write your own code here.
		 */
	}

	/** Looks up a patient in the database. */
	private static void lookUp() {
		/*
		 * TO-DO: Write your own code here.
		 */
	}

	/** Deletes a patient from the database. */
	private static void delete() {
		/*
		 * TO-DO: Write your own code here.
		 */
	}
}
