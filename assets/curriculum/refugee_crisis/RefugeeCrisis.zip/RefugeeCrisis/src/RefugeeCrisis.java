/**
 * Project Two: Refugee Crisis Sentiment Analysis
 * GROUP MEMBER NAMES:
 * 	1)
 * 	2)
 * 	3) 
 * 
 * RefugeeCrisis contains the core implementation of your 
 * natural language processing classification algorithm. Follow
 * the instructions on the accompanying document!
 */

public class RefugeeCrisis {
	
	/**
	 * TODO: implement classify
	 * Returns true if the tweet has a negative attitude 
	 * toward refugees, and false if it has a positive attitude. 
	 */
	public static boolean classify(String phrase) {
		// TODO your code here!
		return false;
	}
	
	/**
	 * Classifies all the data instances as containing negative sentiment or not, 
	 * using the classification algorithm you wrote!
	 */
	public static int[] classifyAll(String[] data) {
		int[] results = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			if (classify(data[i]))
				results[i] = 1;
			else
				results[i] = 0;
		}
		return results;
	}
	
	/**
	 * Feel free to implement this optional method, change it's return
	 * type, and generally do anything you want. Use this method
	 * to programmatically understand the data in a way you might 
	 * not be able to on your own. 
	 * @param data: array of all tweets
	 * @param trueClassifications: parallel array of trueClassifications
	 */
	public static void learn(String[] data, int[] trueClassifications) 
	{
	}
	
	/**
	 * main handles input and uses a sample classifier to understand its accuracy.
	 */
	public static void main(String[] args) {
		// training portion 
		Object[] obj_train = InputHandler.populateData("refugee_train.csv");
		String[] data_train = (String[])obj_train[0];
		int[] train_results = (int[])obj_train[1];
		learn(data_train, train_results);
		
		// testing portion 
		Object[] obj_test = InputHandler.populateData("refugee_test.csv");
		String[] data_test = (String[])obj_test[0];
		int[] test_results = (int[])obj_test[1];
		int[] my_results = classifyAll(data_test);
		
		// Change false to true to print out debugging information! 
		InputHandler.printAccuracy(my_results, test_results, data_test, false);	
		
		// testing on real data! uncomment below when ready 
		/*
		String[] twitterData = TwitterHandler.getTwitterData("refugees");
		int[] twitterResults = classifyAll(twitterData);
		for(int i = 0; i < twitterData.length; i++) {	// classifies real-time tweets!
			System.out.println(twitterResults[i] + " : " + twitterData[i]);
		}
		*/
	}
}
