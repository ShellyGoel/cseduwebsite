import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class InputHandler {

	/**
	 * Returns an object bundling a String array and an int array 
	 * corresponding to a csv file (defined by filename) of ints. 
	 */
	public static Object[] populateData(String filename) {
		ArrayList<String> lines = new ArrayList<String>();
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);

			String currentLine;
			
			while ((currentLine = br.readLine()) != null) {
				lines.add(currentLine);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		String[] data;
		int[] results;
		if(!lines.isEmpty())
		{
			int numLines = lines.size();
			data = new String[numLines];
			results = new int[numLines];
			for(int i = 0; i < numLines; i++) {
				String line = lines.get(i);
				data[i] = line.substring(0, line.length() - 2);
				results[i] = Integer.parseInt(line.substring(line.length() - 1));
			}
		} else {
			data = new String[0];
			results = new int[0];
		}
		
		return new Object[] {data, results};
	}
	
	/**
	 * printAccuracy prints the accuracy of the results stored in myResults
	 * given the actual results from testData. 
	 */
	public static void printAccuracy(int[] myResults, int[] trueResults, 
			String[] data, boolean debug) {
		if(myResults.length != trueResults.length) 
			throw new java.lang.Error("Please provide exactly one classification for each test instance.");
		
		int totalTestInstances = trueResults.length;
		double correctClassifications = 0;
		
		for(int i = 0; i < totalTestInstances; i++) {
			if(myResults[i] == trueResults[i]) 
			{
				correctClassifications++;
				if(debug) System.out.println(data[i]);
			} else if(debug) System.err.println(data[i]);
		}
		
		System.out.printf("Percent Accuracy: %.2f", (correctClassifications/totalTestInstances*100));
		System.out.println("%");
	}
}
