import twitter4j.*;

import java.util.ArrayList;
import java.util.List;

/**
 * The TwitterHandler class uses the twitter4j API
 * to access tweets referring to refugees. 
 */
public class TwitterHandler {
	/**
	 * Gets a stream of tweets corresponding to the searchQuery 
	 * @param searchQuery
	 * @return a array of Strings containing tweet text
	 */
	static String[] getTwitterData (String searchQuery) {
		Twitter twitter = new TwitterFactory().getInstance();
		ArrayList<String> lines = new ArrayList<String>();
        try {
            Query query = new Query(searchQuery);
            QueryResult result;
            //Uncomment do while and add counter for number of tweets to 
            //download more
            //do {
                result = twitter.search(query);
                List<Status> tweets = result.getTweets();
                for (Status tweet : tweets) {
                	lines.add(tweet.getText());
                }
            //} while ((query = result.nextQuery()) != null);
            
            String[] data = new String[lines.size()];
            for(int i = 0; i < data.length; i++) {
            	data[i] = lines.get(i);
            }
            return data;
        } catch (TwitterException te) {
            te.printStackTrace();
            System.out.println("Failed to search tweets: " + te.getMessage());
            return null;
        }
	}
}
