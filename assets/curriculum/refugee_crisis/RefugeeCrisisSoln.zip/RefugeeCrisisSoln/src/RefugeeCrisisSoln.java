/**
 * Project Two: Refugee Crisis Sentiment Analysis
 * SAMPLE SOLUTION
 * 
 * RefugeeCrisis contains a solution implementation for
 * a classification algorithm. The classifier uses the 
 * data to build a map of words to the frequency of their 
 * appearance in hateful/genuine tweets, and uses that 
 * to classify accuracy. 
 * 
 * Several issues exist with this approach. Because the code
 * is trained and tested on the same dataset (something that 
 * will change once we build a better dataset), it is problematic.
 * Moreover, the classification significantly overfits the data 
 * and performs poorly on the live Twitter stream. 
 */


import java.util.HashMap;
import java.util.StringTokenizer;

public class RefugeeCrisisSoln {
	/**
	 * Returns true if negative sentiment is contained 
	 * in the phrase based on the frequency of occurrence of
	 * words compared to the map. 
	 */
	public static boolean classify(String phrase, HashMap<String, Integer> hateWords) {
	    int score = 0;
		for (String token : phrase.toLowerCase().split(" ")) {
	    	if (hateWords.containsKey(token)) {
	    		score += hateWords.get(token);
	    	}
	    }
		if (score > 0) return true;
		return false;
	}
	
	/**
	 * Classifies all the data instances as containing negative sentiment or not, 
	 * using the classification algorithm!
	 */
	public static int[] classifyAll(String[] data, HashMap<String, Integer> hateWords) {
		int[] results = new int[data.length];
		for (int i = 0; i < data.length; i++) {
			if (classify(data[i], hateWords))
				results[i] = 1;
			else
				results[i] = 0;
		}
		return results;
	}
	
	/**
	 * learn learns from the data and builds a hashmap of words to
	 * their frequency of occurrence in positive vs. negative tweets. 
	 */
	public static HashMap<String, Integer> learn(String[] data, int[] trueResults) 
	{
		HashMap<String, Integer> words = new HashMap<String, Integer>();
		for (int i = 0; i < data.length; i++) {
			int classifier = 2*trueResults[i] - 1;
			for (String token : data[i].toLowerCase().split(" ")) {
				if (words.containsKey(token))
					words.put(token, words.get(token) + classifier);
				else
					words.put(token, classifier);
			}			
		}
		return words;	
	}
	
	/**
	 * main handles input and uses a sample classifier to understand its accuracy.
	 */
	public static void main(String[] args) {
		/* training portion */
		Object[] obj_train = InputHandler.populateData("refugee_train.csv");
		String[] data_train = (String[])obj_train[0];
		int[] results_train = (int[])obj_train[1];
		HashMap<String, Integer> hateWords = learn(data_train, results_train);
				
		/* testing portion */
		Object[] obj_test = InputHandler.populateData("refugee_test.csv");		
		String[] data_test = (String[])obj_test[0];
		int[] trueResults = (int[])obj_test[1];
		int[] myResults = classifyAll(data_test, hateWords);
		InputHandler.printAccuracy(myResults, trueResults, data_test, true);	
		
		/* testing on real data! uncomment below when ready */
//		String[] twitterData = TwitterHandler.getTwitterData("refugees");
//		int[] twitterResults = classifyAll(twitterData, hateWords);
//		for(int i = 0; i < twitterData.length; i++) {	// classifies real-time tweets!
//			System.out.println(twitterResults[i] + " : " + twitterData[i]);
//		}
	}
}
